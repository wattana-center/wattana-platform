const colors = {
  primaryColor: '#C99400',
  opacityColor: '#000000'
}

export default { colors: colors }
