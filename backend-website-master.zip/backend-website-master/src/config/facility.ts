const LANGUAGE = [
  'English',
  'Japanese',
  'Mandarin Chinese',
  'Russian',
  'Spanish',
  'Thai'
]

export { LANGUAGE }
