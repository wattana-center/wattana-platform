const ManageRatePlans = () => {
  return <></>
}

export default ManageRatePlans
