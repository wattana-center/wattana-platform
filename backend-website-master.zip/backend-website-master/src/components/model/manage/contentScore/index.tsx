const ManageContentScore = () => {
  return <></>
}

export default ManageContentScore
