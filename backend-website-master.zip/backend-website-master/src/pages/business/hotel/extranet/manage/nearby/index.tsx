import ManageNearby from '@app/components/model/manage/nearby'

const ExtranetManageNearbyPage = () => {
  return (
    <>
      <ManageNearby />
    </>
  )
}

export default ExtranetManageNearbyPage
