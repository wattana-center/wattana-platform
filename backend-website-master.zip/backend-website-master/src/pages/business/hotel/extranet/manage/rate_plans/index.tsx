import ManageRatePlans from '@app/components/model/manage/ratePlans'

const ExtranetManageRatePlansPage = () => {
  return (
    <>
      <ManageRatePlans />
    </>
  )
}

export default ExtranetManageRatePlansPage
